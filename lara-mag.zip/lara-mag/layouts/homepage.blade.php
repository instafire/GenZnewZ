{!! Theme::partial('header') !!}

<section class="home-wrap">
    <div class="container">
        {!! Theme::content() !!}
    </div>
</section>

{!! Theme::partial('footer') !!}
