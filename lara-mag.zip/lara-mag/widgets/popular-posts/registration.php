<?php

require_once __DIR__ . '/popular-posts.php';

register_widget(PopularPostsWidget::class);
