<?php

require_once __DIR__ . '/video-posts.php';

register_widget(VideoPostsWidget::class);
