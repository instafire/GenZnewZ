<?php

require_once __DIR__ . '/text.php';

register_widget(TextWidget::class);
