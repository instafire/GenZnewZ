<?php

require_once __DIR__ . '/ads.php';

register_widget(AdsWidget::class);
