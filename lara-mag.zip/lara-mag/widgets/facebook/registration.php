<?php

require_once __DIR__ . '/facebook.php';

register_widget(FacebookWidget::class);
