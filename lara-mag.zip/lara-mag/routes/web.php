<?php

use Botble\Theme\Facades\Theme;

Theme::routes();
